
import torch
import torch.nn as nn
import torchvision.transforms as transforms
from torchvision import models
import cv2
import numpy as np
import gradio as gr
import os
from PIL import Image

dataset_path = "/content/drive/MyDrive/pest/train"
class_labels = sorted(os.listdir(dataset_path))

model_path = "/content/drive/MyDrive/pest_model.pth"
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

model = models.mobilenet_v2(weights=None)
model.classifier[1] = nn.Linear(model.classifier[1].in_features, len(class_labels))
model.to(device)
model.load_state_dict(torch.load(model_path, map_location=device))
model.eval()

transform = transforms.Compose([
    transforms.Resize((128, 128)),
    transforms.ToTensor(),
    transforms.Normalize(mean=[0.485, 0.456, 0.406],
                         std=[0.229, 0.224, 0.225])
])

pest_info = {
    "aphids": {"treatment": "Use neem oil spray.", "prevention": "Introduce ladybugs.", "medicine": "Neem Oil"},
    "armyworm": {"treatment": "Apply Bacillus thuringiensis.", "prevention": "Crop rotation.", "medicine": "BT"},
    "beetle": {"treatment": "Use insecticidal soap.", "prevention": "Clean field.", "medicine": "Carbaryl"},
    "bollworm": {"treatment": "Apply spinosad.", "prevention": "Pheromone traps.", "medicine": "Spinosad"},
    "grasshopper": {"treatment": "Garlic spray.", "prevention": "Natural predators.", "medicine": "Pyrethroids"},
    "mites": {"treatment": "Sulfur spray.", "prevention": "Reduce dust.", "medicine": "Avermectin"},
    "mosquito": {"treatment": "Larvicides.", "prevention": "Remove stagnant water.", "medicine": "Bti"},
    "sawfly": {"treatment": "Pyrethrin spray.", "prevention": "Parasitic wasps.", "medicine": "Pyrethrin"},
    "stem_borer": {"treatment": "Carbaryl dust.", "prevention": "Resistant crops.", "medicine": "Chlorpyrifos"}
}

def detect_pest_opencv(image):
    img = np.array(image)
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

    lower_brown = np.array([10, 50, 20])
    upper_brown = np.array([30, 255, 200])
    lower_black = np.array([0, 0, 0])
    upper_black = np.array([180, 255, 50])

    mask = cv2.inRange(hsv, lower_brown, upper_brown) | cv2.inRange(hsv, lower_black, upper_black)
    contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    return any(cv2.contourArea(c) > 500 for c in contours)

def predict_pest(image):
    if not detect_pest_opencv(image):
        return "No Pest Detected. Crop Healthy."

    image = transform(image.convert("RGB")).unsqueeze(0).to(device)
    with torch.no_grad():
        output = model(image)
        prob = torch.softmax(output[0], dim=0)
        conf, idx = torch.max(prob, dim=0)

    pest = class_labels[idx.item()]
    info = pest_info.get(pest, {})

    return f"Pest: {pest}\nConfidence: {conf.item()*100:.2f}%\nTreatment: {info.get('treatment')}\nPrevention: {info.get('prevention')}\nMedicine: {info.get('medicine')}"

gr.Interface(
    fn=predict_pest,
    inputs=gr.Image(type="pil"),
    outputs="text",
    title="Advanced Pest Detection System"
).launch(share=True)
